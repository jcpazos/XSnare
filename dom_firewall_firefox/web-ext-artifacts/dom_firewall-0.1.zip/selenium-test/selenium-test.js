const {Builder, By, Key, logging, until} = require('selenium-webdriver');

var firefox = require('selenium-webdriver/firefox');
//logging.installConsoleHandler();
//logging.getLogger('webdriver.http').setLevel(logging.Level.ALL);

const width = 640;
const height = 480;
 
(async function example() {
  
  let driver = await new Builder()
  	.forBrowser('firefox')
  	.setFirefoxOptions(
        new firefox.Options().headless().windowSize({width, height}))
  	/*.setFirefoxService(
            new firefox.ServiceBuilder()
                .enableVerboseLogging()
                .setStdio('inherit'))*/
	.build();

  try {
  	
    await driver.get('http://www.google.com');
    let loadTime = await driver.executeScript('return performance.getEntriesByType("navigation")[0].duration');
    console.log("load time is : " + loadTime);
    await driver.findElement(By.name('q')).sendKeys('cheese!', Key.RETURN);
    //await driver.findElement(By.name('q')).sendKeys('cheese!', Key.RETURN);
    let title = await driver.getTitle();
    console.log('Page title is: ' + title);
    await driver.wait(until.titleIs('cheese! - Google Search'), 1000);
  } catch (err) {
  	console.log('Error: ' + err);
  } finally {
    await driver.quit();
  }
})();